# string = "{\n"

# for item in range(ord("A"),ord("Z")+1,1):
#     string = string + "\t\"" + chr(item)+"\":\n"
# print(string)
