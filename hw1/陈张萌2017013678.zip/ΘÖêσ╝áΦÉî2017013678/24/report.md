# report

- [report](#report)

具体过程为手写+代码辅助计算，详见24.pdf和24.py

经验证，求出的L和k正确
